﻿using GrapeWine.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GrapeWine.Controllers
{
    public class ProductsController : Controller
    {
        ProductDataHelper helper = new ProductDataHelper();

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Info(int id)
        {
            Product product = helper.GetProduct(id);

            return View(product);
        }

        [HttpPost]
        public JsonResult GetProducts(FilterCriteria model)
        {
            return Json(helper.GetProducts(model), JsonRequestBehavior.AllowGet);
        }
    }

    public class FilterCriteria
    {
        public string ProductCountry { get; set; }
        public string Grape { get; set; }
    }

    internal class ProductDataHelper
    {
        private string _connectionString = string.Empty;

        public ProductDataHelper()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["GrapeWineConnection"].ConnectionString;
        }

        public List<Product> GetProducts(FilterCriteria model)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand())
                {
                    try
                    {
                        connection.Open();

                        //add filter here.
                        string where = string.Empty;
                        if (model != null &&
                            (!string.IsNullOrEmpty(model.Grape) || !string.IsNullOrEmpty(model.ProductCountry)))
                        {
                            where = " WHERE ";
                            if (!string.IsNullOrEmpty(model.Grape) && model.Grape.ToLower() != "all")
                                where += "Grape = '" + model.Grape + "'";
                            if (!string.IsNullOrEmpty(model.ProductCountry) && model.ProductCountry.ToLower() != "all")
                                where += "ProductCountry = '" + model.ProductCountry + "'";
                        }

                        command.CommandText = "SELECT * FROM Products '" + (string.IsNullOrEmpty(where) ? where : string.Empty);
                        command.Connection = connection;

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            List<Product> products = new List<Product>();

                            while (reader.Read())
                            {
                                int ProductID = reader.GetOrdinal("ProductID");
                                int ProductName = reader.GetOrdinal("ProductName");
                                int ProductCountry = reader.GetOrdinal("ProductCountry");
                                int ProductType = reader.GetOrdinal("ProductType");
                                int ProductDescription = reader.GetOrdinal("ProductDescription");
                                int Grape = reader.GetOrdinal("Grape");
                                int ImageSrc = reader.GetOrdinal("ImageSrc");
                                int Price = reader.GetOrdinal("Price");

                                products.Add(new Product()
                                {
                                    ProductID = reader.IsDBNull(ProductID) ? 0 : reader.GetInt32(ProductID),
                                    ProductName = reader.IsDBNull(ProductName)
                                        ? string.Empty
                                        : reader.GetString(ProductName),
                                    ProductCountry = reader.IsDBNull(ProductCountry)
                                        ? string.Empty
                                        : reader.GetString(ProductCountry),
                                    ProductType = reader.IsDBNull(ProductType)
                                        ? string.Empty
                                        : reader.GetString(ProductType),
                                    ProductDescription = reader.IsDBNull(ProductDescription)
                                        ? string.Empty
                                        : reader.GetString(ProductDescription),
                                    Grape = reader.IsDBNull(Grape) ? string.Empty : reader.GetString(Grape),
                                    ImageSrc = reader.IsDBNull(ImageSrc) ? string.Empty : reader.GetString(ImageSrc),
                                    Price = reader.IsDBNull(Price) ? 0 : reader.GetDecimal(Price),
                                });
                            }

                            return products;
                        }
                    }
                    catch (Exception)
                    {
                        // Handle error here.
                        return new List<Product>();
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
        }

        public Product GetProduct(int productID)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand())
                {
                    try
                    {
                        connection.Open();

                        command.CommandText = "SELECT * FROM Products WHERE ProductID= @ProductID";

                        SqlParameter sqlParameter = new SqlParameter("@ProductID", System.Data.SqlDbType.Int);
                        sqlParameter.Value = productID;
                        command.Parameters.Add(sqlParameter);

                        command.Connection = connection;

                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            if (reader.HasRows && reader.Read())
                            {
                                return new Product()
                                {
                                    ProductID = reader.GetInt32(reader.GetOrdinal("ProductID")),
                                    ProductName = reader.GetString(reader.GetOrdinal("ProductName")),
                                    ProductCountry = reader.GetString(reader.GetOrdinal("ProductCountry")),
                                    ProductType = reader.GetString(reader.GetOrdinal("ProductType")),
                                    ProductDescription = reader.GetString(reader.GetOrdinal("ProductDescription")),
                                    Grape = reader.GetString(reader.GetOrdinal("Grape")),
                                    ImageSrc = reader.GetString(reader.GetOrdinal("ImageSrc")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                };
                            }
                        }
                    }
                    catch (Exception)
                    {
                        // Handle error here.
                        return null;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }

            return null;

        }

        public ActionResult ShowAllProducts()
        {
            List<Product> product_list = DAO.ShowAll();
            if (product_list.Count == 0)
            {
                ViewBag.error = DAO.message;

            }

            ViewBag.message = product_list.Count;
            return ViewBag(product_list);
        }
    
    }   


}