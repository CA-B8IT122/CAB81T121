﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;
using System.Web.Helpers;
using System.Web.UI.WebControls;
using GrapeWine.Models;

namespace GrapeWine.Controllers
{
    public class DAO : Controller
    {

        SqlConnection con = new SqlConnection();
        public string message = "";

        // GET: dao


        public DAO()
        {
            con = new SqlConnection(WebConfigurationManager.ConnectionStrings["GrapeWineConnection"].ConnectionString);
        }

        public int InsertProduct(Product products)
        {
            int count = 0;
            string message = "";
            SqlCommand cmd = new SqlCommand("usp_InsertProduct", con);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.AddWithValue("@ProductID", products.ProductID);
            cmd.Parameters.AddWithValue("@ProductName", products.ProductName);
            cmd.Parameters.AddWithValue("@ProductCountry", products.ProductCountry);
            cmd.Parameters.AddWithValue("@ProductType", products.ProductType);
            cmd.Parameters.AddWithValue("@ProductDescription", products.ProductDescription);
            cmd.Parameters.AddWithValue("@Grape", products.Grape);
            cmd.Parameters.AddWithValue("@IMageSrc", products.ImageSrc);
            cmd.Parameters.AddWithValue("@Price", products.Price);

            try
            {
                con.Open();

                count = cmd.ExecuteNonQuery();
            }
            catch (SystemException ex)
            {
                message = ex.Message;
            }
            finally
            {
                con.Close();
            }

            return count;
        }

        public List<Product> ShowAll()
        {
            SqlDataReader reader;
            List<Product> cust_list = new List<Product>();

            SqlCommand sql = new SqlCommand("usp_ShowAllProducts", con);

            sql.CommandType = CommandType.StoredProcedure;

            try
            {

                con.Open();
                reader = sql.ExecuteReader();

                while (reader.Read())
                {
                    Product products = new Product();


                    products.ProductID = Convert.ToInt32(reader[0].ToString());
                    products.ProductName = reader[1].ToString();
                    products.ProductCountry = reader[2].ToString();
                    products.ProductType = reader[3].ToString();
                    products.ProductDescription = reader[4].ToString();
                    products.Grape = reader[5].ToString();
                    products.ImageSrc = reader[6].ToString();
                    products.Price = Convert.ToInt32(reader[7].ToString());


                    cust_list.Add(products);
                }
            }
            catch (SystemException ex)
            {
                message = ex.Message;
            }
            finally
            {
                con.Close();
            }

            return cust_list;




        }



    }
}