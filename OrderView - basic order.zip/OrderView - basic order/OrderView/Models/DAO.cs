﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

namespace OrderView.Models
{
    public class DAO
    {
        SqlConnection con;
        public string message = "";
        public DAO()
        {
            con =  new SqlConnection(WebConfigurationManager.ConnectionStrings["conString"].ConnectionString);
        }

        public int InsertOrder(Order order)
        {
            int count = 0;
            SqlCommand cmd = new SqlCommand("uspInsert_tbl_order", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@order", order.ProductID);
            cmd.Parameters.AddWithValue("@customer", order.CustomerID);
            cmd.Parameters.AddWithValue("@type", order.ProductType);
            cmd.Parameters.AddWithValue("@name", order.ProductName);
            cmd.Parameters.AddWithValue("@county", order.Country);
            cmd.Parameters.AddWithValue("@grape", order.Grape);
            cmd.Parameters.AddWithValue("@price", order.Price);
            cmd.Parameters.AddWithValue("@quantity", order.Quantity);
            try
            {
                con.Open();
                count = cmd.ExecuteNonQuery();
            }
            catch (SystemException ex)
            {
                message = ex.Message;
            }
            finally
            {
                con.Close();
            }
            return count;
        }

        
    }
}