﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;
using System.Web.Helpers;
using System.Xml;
using System.IO;

namespace WineOrder.Models
{

    public class DAO
    {
        SqlConnection conn;
        public string message;

        #region constructor
        public DAO()
        {
            conn =
  new SqlConnection(WebConfigurationManager.ConnectionStrings["conString"].ConnectionString);
        }
        #endregion

        #region wines
        public List<Wines> ShowAllWines()
        {
            List<Wines> wineList = new List<Wines>();

            SqlDataReader reader;
            //Creating an instance of SqlCommand 
            SqlCommand cmd;
            //Intialising SqlCommand
            cmd = new SqlCommand("uspAllWines", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Wines wine = new Wines();
                    wine.ProductID = int.Parse(reader["ProductID"].ToString());
                    //Need to figure out how to properly reference the enum here:
                    wine.ProductType = reader["ProductType"].ToString();
                    wine.Country = reader["Country"].ToString();
                    wine.Grape = reader["Grape"].ToString();
                    wine.ProductName = reader["ProductName"].ToString();
                    wine.Price = decimal.Parse(reader["Price"].ToString());
                    wineList.Add(wine);
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            finally
            {
                conn.Close();
            }

            return wineList;
        }

        #endregion

        #region Transaction
        public int AddTransaction(string transactionId, DateTime date, decimal totalPrice, string email)
        {
            int count = 0;
            SqlCommand cmd = new SqlCommand("InsertTransactionTable", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", transactionId);
            cmd.Parameters.AddWithValue("@date", date);
            cmd.Parameters.AddWithValue("@price", totalPrice);
            cmd.Parameters.AddWithValue("@email", email);
            try
            {
                conn.Open();
                count = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            finally
            {
                conn.Close();
            }
            return count;

        }
        public int AddTransactionItem(string transactionId, ItemModel item)
        {
            int count = 0;
            SqlCommand cmd = new SqlCommand("uspTransactionItem", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@tranId", transactionId);
            cmd.Parameters.AddWithValue("@ItemId", item.ItemId);
            cmd.Parameters.AddWithValue("@quantity", item.Quantity);

            try
            {
                conn.Open();
                count = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            finally
            {
                conn.Close();
            }
            return count;
        }
        #endregion

    }
}