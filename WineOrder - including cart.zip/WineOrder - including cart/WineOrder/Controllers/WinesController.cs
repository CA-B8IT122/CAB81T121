﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WineOrder.Models;

namespace SampleTemplate.Controllers
{
    public class WinesController : Controller
    {
        // GET: Book
        DAO dao = new DAO();
        public ActionResult Index()
        {

            List<Wines> winelist = dao.ShowAllWines();
            
            List<int> quantityList = new List<int>() { 1, 2, 3, 4, 5 };
            ViewBag.Quantity = quantityList;
            return View(winelist);
        }
    }
}