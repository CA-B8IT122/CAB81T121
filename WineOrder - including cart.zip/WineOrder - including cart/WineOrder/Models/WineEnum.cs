﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WineOrder.Models
{
    public enum WineEnum
    {
        Rose,
        Red,
        White,
        Prosecco

    }
}