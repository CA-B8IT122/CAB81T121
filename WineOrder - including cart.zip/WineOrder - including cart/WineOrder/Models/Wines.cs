﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WineOrder.Models
{
    public class Wines
    {
        public int ProductID { get; set; }
        public string ProductType { get; set; }
        public string Country { get; set; }
        public string Grape { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }

        public int Quantity { get; set; }

        public Wines()
        {

        }

        public Wines(int productID, string productType, string country, string grape, string productName, decimal price)
        {
            ProductID = productID;
            ProductType = productType;
            Country = country;
            Grape = grape;
            ProductName = productName;
            Price = price;

        }


    }
}